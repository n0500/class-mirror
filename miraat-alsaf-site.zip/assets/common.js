/* مرآة الصف — البيانات المشتركة وطبقة الحفظ */
(function () {
  "use strict";

  var SCHOOL = "المتوسطة الرابعة والثانوية الثانية بالرس";

  /* الفصول العشرون — لكل فصل رمز قصير يُستخدم في رابط QR */
  var CLASSES = [
    { code: "m1-1", name: "أول متوسط 1", stage: "middle_1_2" },
    { code: "m1-2", name: "أول متوسط 2", stage: "middle_1_2" },
    { code: "m1-3", name: "أول متوسط 3", stage: "middle_1_2" },
    { code: "m2-1", name: "ثاني متوسط 1", stage: "middle_1_2" },
    { code: "m2-2", name: "ثاني متوسط 2", stage: "middle_1_2" },
    { code: "m2-3", name: "ثاني متوسط 3", stage: "middle_1_2" },
    { code: "m3-1", name: "ثالث متوسط 1", stage: "middle_3" },
    { code: "m3-2", name: "ثالث متوسط 2", stage: "middle_3" },
    { code: "m3-3", name: "ثالث متوسط 3", stage: "middle_3" },
    { code: "s1-1", name: "أول ثانوي 1", stage: "secondary_1" },
    { code: "s1-2", name: "أول ثانوي 2", stage: "secondary_1" },
    { code: "s1-3", name: "أول ثانوي 3", stage: "secondary_1" },
    { code: "s1-4", name: "أول ثانوي 4", stage: "secondary_1" },
    { code: "s2-1", name: "ثاني ثانوي 1", stage: "secondary_2" },
    { code: "s2-2", name: "ثاني ثانوي 2", stage: "secondary_2" },
    { code: "s2-3", name: "ثاني ثانوي 3", stage: "secondary_2" },
    { code: "s2-4", name: "ثاني ثانوي 4", stage: "secondary_2" },
    { code: "s3-1", name: "ثالث ثانوي 1", stage: "secondary_3" },
    { code: "s3-2", name: "ثالث ثانوي 2", stage: "secondary_3" },
    { code: "s3-3", name: "ثالث ثانوي 3", stage: "secondary_3" }
  ];

  /* المواد حسب الصف/السنة (من subjects-latest.json) — «أخرى» تُضاف تلقائيًا في آخر القائمة */
  /* المواد حسب الصف — العام الدراسي 1448هـ، الفصل الدراسي الأول
     (دليل الخطط الدراسية لوزارة التعليم، مقارنًا بفهرسة مقررات الفصل الأول)
     عند بداية الفصل الثاني تُحدَّث هذه القوائم. زر «أخرى» يُضاف تلقائيًا في كل الصفوف. */
  var SUBJECTS = {
    /* أول متوسط وثاني متوسط */
    middle_1_2: ["القرآن الكريم والدراسات الإسلامية", "اللغة العربية «لغتي الخالدة»", "الدراسات الاجتماعية", "الرياضيات", "العلوم", "اللغة الإنجليزية", "المهارات الرقمية", "التربية الفنية", "التربية البدنية والدفاع عن النفس", "المهارات الحياتية والأسرية"],
    /* ثالث متوسط: المواد السابقة + التفكير الناقد */
    middle_3: ["القرآن الكريم والدراسات الإسلامية", "اللغة العربية «لغتي الخالدة»", "الدراسات الاجتماعية", "الرياضيات", "العلوم", "اللغة الإنجليزية", "المهارات الرقمية", "التربية الفنية", "التربية البدنية والدفاع عن النفس", "المهارات الحياتية والأسرية", "التفكير الناقد"],
    /* أول ثانوي — السنة الأولى المشتركة — ف1 (9 مواد) */
    secondary_1: ["الرياضيات 1-1", "الكيمياء 1", "الأحياء 1", "الكفايات اللغوية 1-1", "اللغة الإنجليزية 1", "القرآن الكريم وتفسيره", "التقنية الرقمية 1", "التفكير الناقد", "التربية الصحية والبدنية 1"],
    /* ثاني ثانوي — المسار العام — ف1 (7 مواد) */
    secondary_2: ["الرياضيات 2-1", "الكيمياء 2-1", "الفيزياء 2", "الأحياء 2-1", "اللغة الإنجليزية 2", "الكفايات اللغوية 2-1", "التاريخ"],
    /* ثالث ثانوي — المسار العام — ف1 */
    secondary_3: ["الرياضيات 3-1", "الفيزياء 3-1", "الكيمياء 3", "علوم الأرض والفضاء", "اللغة الإنجليزية 3", "البحث ومصادر المعلومات", "التربية الصحية والبدنية 2", "التقنية الرقمية 3"]
  };


  var RATINGS = [
    { key: "متميز", cls: "excellent" },
    { key: "جيد", cls: "good" },
    { key: "يحتاج متابعة", cls: "follow" }
  ];
  /* تقديرات النسخة السابقة تُعرض بما يقابلها */
  var LEGACY = { "متوسط": "جيد" };

  function findClass(q) {
    if (!q) return null;
    q = String(q).trim();
    for (var i = 0; i < CLASSES.length; i++) {
      if (CLASSES[i].code === q || CLASSES[i].name === q) return CLASSES[i];
    }
    return null;
  }

  function subjectsFor(cls) {
    return (SUBJECTS[cls.stage] || []).concat(["أخرى"]);
  }

  function normRating(r) { return LEGACY[r] || r; }

  /* عرض أرقام المقررات (مثل 2-1) بترتيبها الصحيح داخل النص العربي، دون تغيير الاسم المحفوظ */
  function disp(name) { return String(name == null ? "" : name).replace(/(\d+(?:-\d+)+)/g, function (m) { return "\u2066" + m.replace(/-/g, "\u2060-\u2060") + "\u2069"; }); }

  /* ---------------- التواريخ ---------------- */
  function startOfWeek(d) { var x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - x.getDay()); return x; }  /* الأحد */
  var HDAY = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", { day: "numeric" });
  function hijriDay(d) { return parseInt(HDAY.format(d), 10); }
  /* بداية الشهر الهجري الذي يقع فيه التاريخ */
  function hijriMonthStart(d) {
    var x = new Date(d); x.setHours(12, 0, 0, 0);
    for (var i = 0; i < 31 && hijriDay(x) !== 1; i++) x.setDate(x.getDate() - 1);
    x.setHours(0, 0, 0, 0); return x;
  }
  function hijriMonthRange(offset) {         /* 0 = الشهر الحالي، -1 = الشهر الماضي */
    var start = hijriMonthStart(new Date());
    for (var k = 0; k > offset; k--) { var p = new Date(start); p.setDate(p.getDate() - 1); start = hijriMonthStart(p); }
    var end = new Date(start); end.setDate(end.getDate() + 25);
    while (hijriDay(end) !== 1) end.setDate(end.getDate() + 1);
    end.setHours(0, 0, 0, 0);
    return { start: start, end: end };
  }
  function hijriMonthLabel(d) {
    var x = new Date(d); x.setDate(x.getDate() + 3);
    return new Intl.DateTimeFormat("ar-SA-u-ca-islamic-umalqura", { month: "long", year: "numeric" }).format(x);
  }

  /* ---------------- طبقة الحفظ ---------------- */
  var cfg = window.MIRAAT_CONFIG || {};
  var fb = cfg.firebaseConfig || {};
  var DEMO = !fb.apiKey || fb.apiKey.indexOf("ضعي") === 0 || !fb.projectId;
  var DEMO_KEY = "miraat_demo_records";
  var V = "10.12.2";
  var G = "https://www.gstatic.com/firebasejs/" + V + "/";

  var fbReady = null;
  function firebase() {
    if (fbReady) return fbReady;
    fbReady = Promise.all([
      import(G + "firebase-app.js"),
      import(G + "firebase-firestore.js"),
      import(G + "firebase-auth.js")
    ]).then(function (m) {
      var app = m[0].initializeApp(fb);
      return { fs: m[1], au: m[2], db: m[1].getFirestore(app), auth: m[2].getAuth(app) };
    });
    return fbReady;
  }

  function demoRead() {
    try { return JSON.parse(localStorage.getItem(DEMO_KEY) || "[]"); } catch (e) { return []; }
  }
  function randomCode() {
    var chars = "abcdefghijkmnpqrstuvwxyz23456789", out = "", buf = new Uint8Array(20);
    (window.crypto || window.msCrypto).getRandomValues(buf);
    for (var i = 0; i < buf.length; i++) out += chars[buf[i] % chars.length];
    return out;
  }
  function demoAdmins() {
    try { return JSON.parse(localStorage.getItem(DEMO_KEY + "_admins") || "[]"); } catch (e) { return []; }
  }
  function demoWrite(rows) {
    try { localStorage.setItem(DEMO_KEY, JSON.stringify(rows)); } catch (e) {}
  }

  var Store = {
    demo: DEMO,

    save: function (rec) {
      var clean = {
        classCode: rec.classCode,
        classroom: rec.classroom,
        stage: rec.stage,
        subject: String(rec.subject || "").slice(0, 80),
        rating: rec.rating,
        note: String(rec.note || "").slice(0, 300)
      };
      if (rec.teacher) clean.teacher = String(rec.teacher).slice(0, 60);   /* اسم المعلمة: عند اختيار «أخرى» فقط */
      if (DEMO) {
        var rows = demoRead();
        clean.id = "d" + Date.now() + Math.random().toString(36).slice(2, 6);
        clean.createdAt = new Date().toISOString();
        rows.push(clean);
        demoWrite(rows);
        return new Promise(function (res) { setTimeout(res, 250); });
      }
      return firebase().then(function (F) {
        clean.createdAt = F.fs.serverTimestamp();
        return F.fs.addDoc(F.fs.collection(F.db, "observations"), clean);
      });
    },

    onAuth: function (cb) {
      if (DEMO) { cb({ email: "وضع التجربة", demo: true }); return; }
      firebase().then(function (F) { F.au.onAuthStateChanged(F.auth, cb); })
        .catch(function () { cb(null); });
    },

    signIn: function (email, pw) {
      return firebase().then(function (F) { return F.au.signInWithEmailAndPassword(F.auth, email, pw); });
    },

    resetPassword: function (email) {
      return firebase().then(function (F) { return F.au.sendPasswordResetEmail(F.auth, email); });
    },

    signOut: function () {
      if (DEMO) return Promise.resolve();
      return firebase().then(function (F) { return F.au.signOut(F.auth); });
    },

    /* تحديد الدور من قاعدة البيانات: "owner" (المالكة) أو "admin" (إدارة) أو null */
    role: function (user) {
      if (!user) return Promise.resolve(null);
      if (user.demo) return Promise.resolve("owner");
      var email = String(user.email || "").toLowerCase();
      return firebase().then(function (F) {
        /* قراءة إعدادات الدعوة مسموحة للمالكة فقط وفق قواعد الحماية */
        return F.fs.getDoc(F.fs.doc(F.db, "settings", "invite")).then(function () { return "owner"; }, function () {
          return F.fs.getDoc(F.fs.doc(F.db, "admins", email)).then(function (d) {
            return d.exists() && !d.data().blocked ? (d.data().canDelete ? "admin-del" : "admin") : null;
          }, function () { return null; });
        });
      });
    },

    signUp: function (email, pw) {
      return firebase().then(function (F) { return F.au.createUserWithEmailAndPassword(F.auth, email, pw); });
    },

    /* تسجيل حساب إدارة عبر رابط الدعوة */
    joinWithInvite: function (user, name, code) {
      var email = String(user.email || "").toLowerCase();
      return firebase().then(function (F) {
        return F.fs.setDoc(F.fs.doc(F.db, "admins", email), {
          name: String(name || "").trim().slice(0, 60), invite: String(code), addedAt: F.fs.serverTimestamp()
        });
      });
    },

    /* رمز الدعوة: يُنشأ تلقائيًا أول مرة، ويمكن تغييره لإبطال الرابط القديم */
    getInvite: function (renew) {
      if (DEMO) {
        var c = null;
        try { c = localStorage.getItem(DEMO_KEY + "_invite"); } catch (e) {}
        if (!c || renew) { c = randomCode(); try { localStorage.setItem(DEMO_KEY + "_invite", c); } catch (e) {} }
        return Promise.resolve(c);
      }
      return firebase().then(function (F) {
        var ref = F.fs.doc(F.db, "settings", "invite");
        return F.fs.getDoc(ref).then(function (d) {
          if (d.exists() && d.data().code && !renew) return d.data().code;
          var code = randomCode();
          return F.fs.setDoc(ref, { code: code, updatedAt: F.fs.serverTimestamp() }).then(function () { return code; });
        });
      });
    },

    listAdmins: function () {
      if (DEMO) return Promise.resolve(demoAdmins());
      return firebase().then(function (F) {
        return F.fs.getDocs(F.fs.collection(F.db, "admins"));
      }).then(function (snap) {
        var out = [];
        snap.forEach(function (d) {
          var x = d.data(); x.email = d.id;
          x.addedAt = x.addedAt && x.addedAt.toDate ? x.addedAt.toDate() : null;
          out.push(x);
        });
        out.sort(function (a, b) { return (b.addedAt || 0) - (a.addedAt || 0); });
        return out;
      });
    },

    /* إيقاف الحساب أو إعادة تفعيله (الإيقاف يمنع العودة حتى برابط الدعوة) */
    setBlocked: function (email, blocked) {
      if (DEMO) {
        var list = demoAdmins().map(function (a) { if (a.email === email) a.blocked = blocked; return a; });
        try { localStorage.setItem(DEMO_KEY + "_admins", JSON.stringify(list)); } catch (e) {}
        return Promise.resolve();
      }
      return firebase().then(function (F) { return F.fs.updateDoc(F.fs.doc(F.db, "admins", email), { blocked: !!blocked }); });
    },

    /* صلاحية حذف التقييمات لحساب إدارة (تمنحها المالكة) */
    setCanDelete: function (email, v) {
      if (DEMO) {
        var list = demoAdmins().map(function (a) { if (a.email === email) a.canDelete = !!v; return a; });
        try { localStorage.setItem(DEMO_KEY + "_admins", JSON.stringify(list)); } catch (e) {}
        return Promise.resolve();
      }
      return firebase().then(function (F) { return F.fs.updateDoc(F.fs.doc(F.db, "admins", email), { canDelete: !!v }); });
    },

    /* ===== لوحة إنجازات الأسبوع (بيانات إيجابية فقط، قابلة للقراءة العامة) ===== */
    publishBoard: function (data) {
      if (DEMO) { try { localStorage.setItem(DEMO_KEY + "_board", JSON.stringify(data)); } catch (e) {} return Promise.resolve(); }
      return firebase().then(function (F) {
        var d = JSON.parse(JSON.stringify(data));
        d.updatedAt = F.fs.serverTimestamp();
        return F.fs.setDoc(F.fs.doc(F.db, "public", "weekly"), d);
      });
    },
    getBoard: function () {
      if (DEMO) { try { return Promise.resolve(JSON.parse(localStorage.getItem(DEMO_KEY + "_board") || "null")); } catch (e) { return Promise.resolve(null); } }
      return firebase().then(function (F) {
        return F.fs.getDoc(F.fs.doc(F.db, "public", "weekly"));
      }).then(function (d) {
        if (!d.exists()) return null;
        var x = d.data();
        x.updatedAt = x.updatedAt && x.updatedAt.toDate ? x.updatedAt.toDate().toISOString() : null;
        return x;
      });
    },

    /* تُرجع جميع السجلات منذ تاريخ معيّن (أو كلها) مرتبة من الأحدث */
    list: function (since) {
      if (DEMO) {
        var rows = demoRead().filter(function (r) { return !since || new Date(r.createdAt) >= since; });
        rows.sort(function (a, b) { return a.createdAt < b.createdAt ? 1 : -1; });
        return Promise.resolve(rows.map(function (r) { r.createdAt = new Date(r.createdAt); return r; }));
      }
      return firebase().then(function (F) {
        var parts = [F.fs.collection(F.db, "observations")];
        if (since) parts.push(F.fs.where("createdAt", ">=", F.fs.Timestamp.fromDate(since)));
        parts.push(F.fs.orderBy("createdAt", "desc"));
        return F.fs.getDocs(F.fs.query.apply(null, parts));
      }).then(function (snap) {
        var out = [];
        snap.forEach(function (d) {
          var x = d.data();
          x.id = d.id;
          x.createdAt = x.createdAt && x.createdAt.toDate ? x.createdAt.toDate() : new Date();
          out.push(x);
        });
        return out;
      });
    },

    /* حذف موثَّق: يُسجَّل التقييم المحذوف ومن حذفه ووقت الحذف وسببه في «سجل الحذف» ضمن العملية نفسها */
    remove: function (rec, reason) {
      var copy = {
        classCode: rec.classCode || "", classroom: rec.classroom || "", subject: rec.subject || "",
        rating: rec.rating || "", note: rec.note || "", teacher: rec.teacher || ""
      };
      if (DEMO) {
        demoWrite(demoRead().filter(function (r) { return r.id !== rec.id; }));
        var log = [];
        try { log = JSON.parse(localStorage.getItem(DEMO_KEY + "_deletions") || "[]"); } catch (e) {}
        copy.createdAt = new Date(rec.createdAt).toISOString();
        log.unshift({ id: rec.id, by: "وضع التجربة", at: new Date().toISOString(), reason: reason, record: copy });
        try { localStorage.setItem(DEMO_KEY + "_deletions", JSON.stringify(log)); } catch (e) {}
        return Promise.resolve();
      }
      return firebase().then(function (F) {
        var obsRef = F.fs.doc(F.db, "observations", rec.id);
        return F.fs.getDoc(obsRef).then(function (snap) {
          if (!snap.exists()) throw new Error("not-found");
          var d = snap.data();
          var b = F.fs.writeBatch(F.db);
          b.set(F.fs.doc(F.db, "deletions", rec.id), {
            by: String(F.auth.currentUser.email || "").toLowerCase(),
            at: F.fs.serverTimestamp(),
            reason: String(reason || "").slice(0, 200),
            record: {
              classCode: d.classCode || "", classroom: d.classroom || "", subject: d.subject || "",
              rating: d.rating || "", note: d.note || "", teacher: d.teacher || "", createdAt: d.createdAt
            }
          });
          b.delete(obsRef);
          return b.commit();
        });
      });
    },

    /* سجل الحذف */
    listDeletions: function () {
      if (DEMO) {
        var log = [];
        try { log = JSON.parse(localStorage.getItem(DEMO_KEY + "_deletions") || "[]"); } catch (e) {}
        return Promise.resolve(log.map(function (x) { x.at = new Date(x.at); x.record.createdAt = new Date(x.record.createdAt); return x; }));
      }
      return firebase().then(function (F) {
        return F.fs.getDocs(F.fs.query(F.fs.collection(F.db, "deletions"), F.fs.orderBy("at", "desc")));
      }).then(function (snap) {
        var out = [];
        snap.forEach(function (d) {
          var x = d.data(); x.id = d.id;
          x.at = x.at && x.at.toDate ? x.at.toDate() : new Date();
          x.record = x.record || {};
          x.record.createdAt = x.record.createdAt && x.record.createdAt.toDate ? x.record.createdAt.toDate() : null;
          out.push(x);
        });
        return out;
      });
    },

    /* بيانات تجريبية لمعاينة لوحة المتابعة في وضع التجربة فقط */
    seedDemo: function () {
      if (!DEMO) return;
      var rows = [], now = Date.now();
      var weights = [0.42, 0.4, 0.18];
      for (var i = 0; i < 140; i++) {
        var c = CLASSES[Math.floor(Math.random() * CLASSES.length)];
        var subs = SUBJECTS[c.stage];
        var p = Math.random(), r = p < weights[0] ? 0 : p < weights[0] + weights[1] ? 1 : 2;
        rows.push({
          id: "s" + i, classCode: c.code, classroom: c.name, stage: c.stage,
          subject: subs[Math.floor(Math.random() * subs.length)],
          rating: RATINGS[r].key, note: "",
          createdAt: new Date(now - Math.random() * 30 * 864e5).toISOString()
        });
      }
      demoWrite(demoRead().concat(rows));
    },
    clearDemo: function () { if (DEMO) demoWrite([]); }
  };

  window.Miraat = {
    SCHOOL: SCHOOL, CLASSES: CLASSES, SUBJECTS: SUBJECTS, RATINGS: RATINGS,
    findClass: findClass, subjectsFor: subjectsFor, disp: disp, startOfWeek: startOfWeek, hijriMonthRange: hijriMonthRange, hijriMonthLabel: hijriMonthLabel, normRating: normRating, Store: Store
  };
})();
